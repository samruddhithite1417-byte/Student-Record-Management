# Student Record Management System
C mini project for engineering students.

## Features
Add, display, search, update, delete, sort by roll number, and save/load records.

## Compile and run
Windows with GCC/MinGW:
```bash
gcc student_record_management.c -o student_records
student_records.exe
```
Linux/macOS:
```bash
gcc student_record_management.c -o student_records
./student_records
```
Records are stored in `students.txt` in the program's working directory. The program supports up to 200 records. Do not include the `|` character in names or course names.
