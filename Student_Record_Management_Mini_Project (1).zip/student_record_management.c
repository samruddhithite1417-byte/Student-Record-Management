#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 200
#define NAME 60
#define COURSE 40
#define FILE_NAME "students.txt"

typedef struct {
    int roll;
    char name[NAME], course[COURSE];
    float marks;
} Student;

Student s[MAX];
int n=0;

void trim(char *x){ size_t k=strlen(x); if(k && x[k-1]=='\n') x[k-1]='\0'; }
int readInt(const char *p){
    char b[100], extra; int v;
    for(;;){ printf("%s",p); if(!fgets(b,sizeof b,stdin)) exit(0);
        if(sscanf(b," %d %c",&v,&extra)==1) return v;
        puts("Invalid number. Try again.");
    }
}
float readFloat(const char *p){
    char b[100], extra; float v;
    for(;;){ printf("%s",p); if(!fgets(b,sizeof b,stdin)) exit(0);
        if(sscanf(b," %f %c",&v,&extra)==1) return v;
        puts("Invalid number. Try again.");
    }
}
void readText(const char *p,char *out,size_t cap){
    for(;;){ printf("%s",p); if(!fgets(out,(int)cap,stdin)) exit(0); trim(out);
        if(out[0] && !strchr(out,'|')) return;
        puts("Text cannot be empty or contain |.");
    }
}
int find(int roll){ for(int i=0;i<n;i++) if(s[i].roll==roll) return i; return -1; }
void load(void){
    FILE *f=fopen(FILE_NAME,"r"); if(!f) return; Student x;
    while(n<MAX && fscanf(f,"%d|%59[^|]|%39[^|]|%f\n",&x.roll,x.name,x.course,&x.marks)==4) s[n++]=x;
    fclose(f);
}
int save(void){
    FILE *f=fopen(FILE_NAME,"w"); if(!f){ puts("Could not save file."); return 0; }
    for(int i=0;i<n;i++) fprintf(f,"%d|%s|%s|%.2f\n",s[i].roll,s[i].name,s[i].course,s[i].marks);
    fclose(f); return 1;
}
void add(void){
    if(n>=MAX){ puts("Record limit reached."); return; }
    Student x; x.roll=readInt("Roll number: ");
    if(x.roll<=0 || find(x.roll)>=0){ puts("Roll number must be positive and unique."); return; }
    readText("Student name: ",x.name,sizeof x.name); readText("Course/department: ",x.course,sizeof x.course);
    x.marks=readFloat("Marks (0-100): ");
    if(x.marks<0 || x.marks>100){ puts("Invalid marks; record not added."); return; }
    s[n++]=x; if(save()) puts("Record added and saved.");
}
void display(void){
    if(!n){ puts("No records found."); return; }
    printf("\n%-10s %-25s %-25s %-8s\n","Roll","Name","Course","Marks");
    puts("-----------------------------------------------------------------------");
    for(int i=0;i<n;i++) printf("%-10d %-25.25s %-25.25s %-8.2f\n",s[i].roll,s[i].name,s[i].course,s[i].marks);
}
void search(void){
    int r=readInt("Roll number to search: "),i=find(r);
    if(i<0){ puts("Record not found."); return; }
    printf("Roll: %d\nName: %s\nCourse: %s\nMarks: %.2f\n",s[i].roll,s[i].name,s[i].course,s[i].marks);
}
void update(void){
    int r=readInt("Roll number to update: "),i=find(r); if(i<0){ puts("Record not found."); return; }
    readText("New name: ",s[i].name,sizeof s[i].name); readText("New course/department: ",s[i].course,sizeof s[i].course);
    float m=readFloat("New marks (0-100): "); if(m<0 || m>100){ puts("Invalid marks; update cancelled."); return; }
    s[i].marks=m; if(save()) puts("Record updated.");
}
void removeRecord(void){
    int r=readInt("Roll number to delete: "),i=find(r); if(i<0){ puts("Record not found."); return; }
    for(int j=i;j<n-1;j++) s[j]=s[j+1]; n--; if(save()) puts("Record deleted.");
}
void sortRecords(void){
    for(int i=0;i<n-1;i++) for(int j=0;j<n-i-1;j++) if(s[j].roll>s[j+1].roll){
        Student t=s[j]; s[j]=s[j+1]; s[j+1]=t;
    }
    puts("Sorted by roll number."); display();
}
int main(void){
    load(); printf("Loaded %d record(s).\n",n); int c;
    do{
        puts("\n=== STUDENT RECORD MANAGEMENT SYSTEM ===");
        puts("1 Add  2 Display  3 Search  4 Update  5 Delete  6 Sort  7 Save  0 Exit");
        c=readInt("Choice: ");
        switch(c){
            case 1:add();break; case 2:display();break; case 3:search();break;
            case 4:update();break; case 5:removeRecord();break; case 6:sortRecords();break;
            case 7:if(save()) puts("Saved.");break;
            case 0:if(save()) puts("Saved. Goodbye.");break;
            default:puts("Invalid choice.");
        }
    }while(c!=0);
    return 0;
}
